package com.example.rezerva.utils.observer;

public interface Observer{
    void update();
}
