package com.example.rezerva.service;

public class Service {
}
