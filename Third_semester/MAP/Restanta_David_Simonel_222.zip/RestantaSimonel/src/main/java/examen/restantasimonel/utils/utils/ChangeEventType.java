package examen.restantasimonel.utils.utils;

public enum ChangeEventType {
    ADD, UPDATE
}
