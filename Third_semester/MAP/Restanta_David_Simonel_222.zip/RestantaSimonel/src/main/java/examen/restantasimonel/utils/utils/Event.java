package examen.restantasimonel.utils.utils;

public interface Event {
}
