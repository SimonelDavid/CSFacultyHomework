package examen.restantasimonel.repository.factory;

public enum RepositoryEntity {
    TEST, INTREBARE
}
