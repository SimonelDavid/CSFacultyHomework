%list-integer*
%adaugare la sfarsitul unei liste
%adaug(E:integer, L:list, LRez:list)
%(i,i,o),(i,i,i)
adaug(E,[],[E]).
adaug(E,[H|T],[H|L]):-adaug(E,T,L).

%inversa unei liste
%invers(L:list, LRez:list)
%(i,o),(i,i)
invers([],[]).
invers([H|T],LRez):-invers(T,L), adaug(H,L,LRez).

%adaugare cu transport
%sum(L:list, Tr:integer, LRez:list)
%(i,o),(i,i)
sum([],Tr,[Tr]):-Tr>0.
sum([],Tr,[]):-Tr=0.
sum([H|T],Tr,[R|LRez]) :- R1 is H+Tr,
                        R is R1 mod 10, Tr1 is R1 div 10, sum(T,Tr1,LRez).

%succesor(L:list, LS:list)
%(i,o),(i,i)
succesor(L,LS):- invers(L,LI), sum(LI,1,LA), invers(LA,LS).

%subliste(L:lista eterogena, R:lista eterogena)
%(i,o),(i,i)
subliste([],[]).
subliste([H|T],[H|L]):-not(is_list(H)), subliste(T,L).
subliste([H|T],[L1|L]):-is_list(H), succesor(H,L1), subliste(T,L), write(L).

