package com.wms.wmsproject.utils.enums;

public enum TaskType {
    ADMINISTRATIVE, LOGISTIC, HARD, OTHERS,
}
