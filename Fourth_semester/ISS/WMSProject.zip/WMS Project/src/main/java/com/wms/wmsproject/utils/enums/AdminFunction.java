package com.wms.wmsproject.utils.enums;

public enum AdminFunction {
    CEO, DEPARTMENT_LEADER, TEAM_LEADER,
}
