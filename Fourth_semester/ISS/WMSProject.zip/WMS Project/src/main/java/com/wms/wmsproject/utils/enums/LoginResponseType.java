package com.wms.wmsproject.utils.enums;

public enum LoginResponseType {
    WORKER, ADMIN, FAILED
}
