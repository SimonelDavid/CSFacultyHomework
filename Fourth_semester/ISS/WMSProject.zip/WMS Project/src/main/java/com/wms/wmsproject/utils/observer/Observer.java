package com.wms.wmsproject.utils.observer;

public interface Observer {
    void update();
}
