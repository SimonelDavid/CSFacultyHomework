from Domain.client import Client, ClientAccount
from Domain.book import Book, Copies

from Repository.client_repo import ConturiClientiRepository
from Repository.book_repo import RepoBookCopies

from Validation.client_validator import ClientValidator
from Validation.book_validator import BookValidator

from Service.client_service import ServiceClient
from Service.book_service import BookService

import colorama
colorama.init()

class TestClient():

    def __test_create_client(self):
        id_client = 1
        nume = "Pop Ion"
        cnp = "12345678"
        client1 = Client(id_client, nume, cnp)
        assert (client1.get_id_client() == id_client)
        assert (client1.get_nume() == nume)
        assert (client1.get_cnp() == cnp)

    def __test_modify_client(self):
        client1 = Client(1, "Pop Ion", "1234567890123")
        client1.set_id_client(2)
        client1.set_nume("Matei")
        client1.set_cnp("1234567890123")
        assert (client1.get_id_client() == 2)
        assert (client1.get_nume() == "Matei")
        assert (client1.get_cnp() == "1234567890123")

    def __test_client_eq(self):
        id_client = 1
        nume = "Pop Ion"
        cnp = "1234567890123"
        client1 = Client(id_client, nume, cnp)
        client2 = Client(1, "Pop Ion", "1234567890123")
        assert (client1 == client2)

    def __test_account_client_eq(self):
        id_client = 1
        nume = "Pop Ion"
        cnp = "1234567890123"
        cont_client1 = ClientAccount(Client(id_client, nume, cnp))
        cont_client2 = ClientAccount(Client(1, "Pop Ion", "1234567890123"))
        cont_client1.add_book(Book(1, "Moara", "-", "Slavici"))
        cont_client2.add_book(Book(1, "Moara", "-", "Slavici"))
        assert (cont_client1 == cont_client2)

    def __test_create_client_account(self):
        id_client = 1
        nume = "Pop Ion"
        cnp = "12345678"
        client1 = Client(id_client, nume, cnp)
        cont_client1 = ClientAccount(client1)
        assert (cont_client1.get_client() == client1)
        assert (cont_client1.get_numar_inchirieri_total() == 0)
        assert (cont_client1.get_carti_inchiriate() == [])

    def __test_delete_book_from_account(self):
        cont1 = ClientAccount(Client(1, "Andrei", "1234567890122"))
        cont1.add_book(Book(1, "Moara", "pentru bac", "Slavici"))
        cont1.add_book(Book(2, "Baltagul", "roman", "Sadoveanu"))
        Book1 = Book(1, "Moara", "pentru bac", "Slavici")
        Book2 = Book(2, "Baltagul", "roman", "Sadoveanu")
        assert (cont1.get_carti_inchiriate() == [Book1, Book2])
        cont1.delete_book(0)
        assert (cont1.get_carti_inchiriate() == [Book2])
        assert (cont1.get_numar_inchirieri_total() == 2)

    def run_teste_client(self):
        self.__test_create_client()
        self.__test_client_eq()
        self.__test_create_client_account()
        self.__test_delete_book_from_account()
        self.__test_account_client_eq()
        self.__test_modify_client
()


class TestClientValidator():

    def __test_client_validator(self):
        validator_client = ClientValidator()
        validator_client.validare_date_client(2, "Andrei", "1234567890123")
        validator_client.validare_date_client(100, "Marius", "1234567890123")
        try:
            validator_client.validare_date_client(-1, "Andrei", "1234567890123")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id client invalid!\n")

    def __test_validate_unicity(self):
        validator_client = ClientValidator()
        repository_client = ConturiClientiRepository()
        repository_client.add_cont(ClientAccount(Client(1, "Andrei", "1234567890123")))
        repository_client.add_cont(ClientAccount(Client(2, "Mihai", "1234567890123")))
        validator_client.validare_unicitate(repository_client, "1111", "3")
        try:
            validator_client.validare_unicitate(repository_client, "1234567890123", 1)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id-ul exista deja!\ncnp-ul exista deja!\n")

        try:
            validator_client.validare_unicitate(repository_client, "1234567890123", 3)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "cnp-ul exista deja!\n")

    def __test_client_cnp_validator(self):
        client_repository = ConturiClientiRepository()
        client_validator = ClientValidator()

        client_repository.add_cont(ClientAccount(Client(1, "Andrei", "1234567890123")))
        client_validator.validare_cnp_client(client_repository, "1234567890120")
        try:
            client_validator.validare_cnp_client(client_repository, "123AA45")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "cnp invalid!\n")

        try:
            client_validator.validare_cnp_client(client_repository, "1234567890123")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "cnp-ul exista deja!\n")

    def run_teste_validare_client(self):
        self.__test_client_validator()
        self.__test_validate_unicity()
        self.__test_client_cnp_validator()


class BookTest():

    def __test_book_creator(self):
        id_Book = 1
        titlu = "Ion"
        descriere = "roman interbelic"
        autor = "Liviu Rebreanu"
        Book1 = Book(id_Book, titlu, descriere, autor)
        assert (titlu == Book1.get_titlu())
        assert (descriere == Book1.get_descriere())
        assert (id_Book == Book1.get_book_id())
        assert (autor == Book1.get_autor())
    
    def __test_book_modifier(self):
        book = Book(1,"Despre libertate","carte filosofica","John Stuart Mill")
        book.set_book_id(2)
        book.set_title("Moara cu noroc")
        book.set_description("nuvela psihologica")
        book.set_author("Ioan Slavici")
        assert(book.get_book_id() == 2)
        assert(book.get_titlu() == "Moara cu noroc")
        assert(book.get_autor() == "Ioan Slavici")
        assert(book.get_descriere() == "nuvela psihologica")


    def __test_equals_books(self):
        id_Book = 1
        titlu = "Baltagul"
        descriere = "frumos"
        autor = "M. Sadoveanu"
        Book1 = Book(id_Book, titlu, descriere, autor)
        Book2 = Book(1, "Baltagul", descriere, "M. Sadoveanu")
        Book3 = Book(id_Book, titlu, descriere, "False")
        assert (Book1 == Book2)
        assert (Book1 != Book3)
    
    def __test_search_books(self):
        book_repo = RepoBookCopies()
        book_validator = BookValidator()
        book_service = BookService(book_validator, book_repo)

        book_service.add_book(1,"Joyland","Carte misterioasa","Stephen King",5)
        book_service.add_book(2,"Joyland","Aventrua","Emily Schultz",12)
        book_service.add_book(3,"It","Horror","Stephen King",10)

        book = book_service.get_book_by_id(1)
        book1 = book_service.get_book_by_id(2)
        book2 = book_service.get_book_by_id(3)
#client.get_client().get_id_client()
        local_books = []
        local_books.append(book.get_book().get_book_id())
        local_books.append(book1.get_book().get_book_id())

        assert(book_repo.search_book_by_id(3) == book2)
        assert(book_repo.search_books_by_title("Joyland") == local_books)

        local_books = []
        local_books.append(book.get_book().get_book_id())
        local_books.append(book2.get_book().get_book_id())

        assert(book_repo.search_books_by_author("Stephen King") == local_books)


    def run_teste_Book(self):
        self.__test_book_creator()
        self.__test_equals_books()
        self.__test_book_modifier()
        self.__test_search_books()


class BookValidatorTest():

    def __book_validator_test(self):
        validator_Book = BookValidator()
        validator_Book.book_data_validator(1, "Moara", "descriere", "Slavici")
        try:
            validator_Book.book_data_validator(-1, " ", "-", "123")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id carte invalid!\ntitlu carte invalid!\nnume autor invalid!\n")
        try:
            validator_Book.book_data_validator(1, "", "", "Mihai")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "titlu carte invalid!\ndescriere carte invalida!\n")

    def __book_unicity_validator_test(self):
        Book_repository = RepoBookCopies()
        Book_repository.add_exemplar(Copies(Book(1, "Moara", "bac", "Slavici"), 5))
        Book_repository.add_exemplar(Copies(Book(2, "Ion", "bac", "Rebreanu"), 7))
        Book_validator = BookValidator()
        try:
            Book_validator.validare_unicitate(Book_repository, 3, "Ion", "Rebreanu")
            assert(False)
        except Exception as ex:
            assert (str(ex) == "carte deja existenta!\n")
        try:
            Book_validator.validare_unicitate(Book_repository, 1, "Iooon", "Rebreanu")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id deja existent!\n")

        try:
            Book_validator.validare_unicitate(Book_repository, 1, "Ion", "Rebreanu")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id deja existent!\ncarte deja existenta!\n")

    def run_teste_validare_Book(self):
        self.__book_validator_test()
        self.__book_unicity_validator_test()


class TestClientsRepoAccounts():

    def __test_clients_repo_accounts(self):
        repo_cont_client = ConturiClientiRepository()
        assert (repo_cont_client.get_repository() == [])
        cont_client1 = ClientAccount(Client(1, "Andrei", "123"))
        cont_client2 = ClientAccount(Client(2, "Marius", "234"))
        repo_cont_client.add_cont(cont_client1)
        assert (len(repo_cont_client.get_repository()) == 1)
        assert (repo_cont_client.get_repository() == [cont_client1])
        repo_cont_client.add_cont(cont_client2)
        assert (len(repo_cont_client.get_repository()) == 2)
        assert (repo_cont_client.get_repository() == [cont_client1, cont_client2])
        repo_cont_client.delete_cont(0)
        assert (repo_cont_client.get_repository() == [cont_client2])

    def __test_create_new_account(self):
        repo_cont_client = ConturiClientiRepository()
        assert (repo_cont_client.creare_cont_nou(1, "Andrei", "1234") == ClientAccount(Client(1, "Andrei", "1234")))

    def __test_get_account_by_id(self):
        repository_client = ConturiClientiRepository()
        cont_client1 = ClientAccount(Client(1, "Andrei", "1234"))
        cont_client2 = ClientAccount(Client(2, "Mircea", "2345"))
        cont_client3 = ClientAccount(Client(3, "Ana", "4352"))
        repository_client.add_cont(cont_client1)
        repository_client.add_cont(cont_client2)
        repository_client.add_cont(cont_client3)
        assert (repository_client.get_cont_by_id(1) == cont_client1)
        assert (repository_client.get_cont_by_id(2) == cont_client2)
        try:
            repository_client.get_cont_by_id(5)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id inexistent!\n")


    def run_teste_repository_clienti(self):
        self.__test_clients_repo_accounts()
        self.__test_create_new_account()
        self.__test_get_account_by_id()


class TestCopies():

    def __test_create_a_copy(self):
        book = Book(1, "Luceafarul", "poezie bac", "Mihai Eminescu")
        exemplar = Copies(book, 5)
        assert (exemplar.get_book() == book)
        assert (exemplar.get_Copies_number() == 5)
        exemplar.add_copies(4)
        assert (exemplar.get_Copies_number() == 9)

    def run_teste_Copies(self):
        self.__test_create_a_copy()


class TestBooksRepoCopies():

    def __test_create_copies_repo(self):
        exemplar1 = Copies(Book(1, "Moara", "pt bac", "Slavici"), 10)
        exemplar2 = Copies(Book(2, "Hanul Ancutei", "povesti", "M. Sadoveanu"), 2)
        repo_Copies = RepoBookCopies()
        repo_Copies.add_exemplar(exemplar1)
        assert (repo_Copies.get_repository() == [exemplar1])
        repo_Copies.add_exemplar(exemplar2)
        assert (repo_Copies.get_repository() == [exemplar1, exemplar2])
        repo_Copies.delete_exemplar(0)
        assert (repo_Copies.get_repository() == [exemplar2])

    def __test_create_copies(self):
        Book_repository = RepoBookCopies()
        exemplar = Copies(Book(1, "Ion", "-", "Ion Rebreanu"), 5)
        assert (Book_repository.creare_exemplar(1, "Ion", "-", "Ion Rebreanu", 5) == exemplar)

    def __test_book_max_title(self):
        repository_Book = RepoBookCopies()
        Book1 = Copies(Book(1, "Ion", "--", "Liviu Rebreanu"), 6)
        Book2 = Copies(Book(2, "Moara cu noroc", "--", "Ioan Slavici"), 10)
        repository_Book.add_exemplar(Book1)
        repository_Book.add_exemplar(Book2)

        assert(repository_Book.max_book_title_repository() == Book2)

        Book3 = Copies(Book(3, "Enigma Otiliei", "--", "G. Calinescu"), 2)
        repository_Book.add_exemplar(Book3)

        assert(repository_Book.max_book_title_repository() == Book3)

        Book4 = Copies(Book(4, "Floare Albastra", "--", "M. Eminescu"), 4)
        repository_Book.add_exemplar(Book4)

        assert(repository_Book.max_book_title_repository() == Book4)


    def run_teste_repository_Copies(self):
        self.__test_create_copies_repo()
        self.__test_create_copies()
        self.__test_book_max_title()


class TestServiceClient():

    def __test_create_service_client(self):
        repository_client = ConturiClientiRepository()
        validator_client = ClientValidator()
        service_client = ServiceClient(validator_client, repository_client)
        assert (service_client.get_repository_client() == repository_client)
        assert (service_client.get_validator_client() == validator_client)

    def __test_add_client(self):
        repository_client = ConturiClientiRepository()
        validator_client = ClientValidator()
        service_client = ServiceClient(validator_client, repository_client)
        assert (service_client.get_repository_client().get_repository() == [])
        service_client.adauga_client(1, "Andrei", "1234567890120")
        service_client.adauga_client(2, "Mihai", "1234567890123")
        try:
            service_client.adauga_client(-1, "Andrei", "cnp_invalid")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id client invalid!\ncnp invalid!\n")

        try:
            service_client.adauga_client(1, "Cosmin", "1234567890120")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id-ul exista deja!\ncnp-ul exista deja!\n")

    def __test_get_client_by_id(self):
        repository_client = ConturiClientiRepository()
        validator_client = ClientValidator()
        service_client = ServiceClient(validator_client, repository_client)
        repository_client.add_cont(ClientAccount(Client(1, "Andrei", "1234")))
        assert (service_client.get_client_by_id(1) == ClientAccount(Client(1, "Andrei", "1234")))
        try:
            service_client.get_client_by_id(-1)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id client invalid!\n")
        try:
            service_client.get_client_by_id(3)
            assert(False)
        except Exception as ex:
            assert (str(ex) == "id inexistent!\n")

    def __test_modify_client_cnp(self):
        client_repository = ConturiClientiRepository()
        client_validator = ClientValidator()
        client_service = ServiceClient(client_validator, client_repository)

        client_service.adauga_client(1, "Andrei", "1234567890129")
        client_service.adauga_client(2, "Mihai", "1234567890121")

        cont = client_service.get_client_by_id(1)
        client_service.modificare_cnp_client(cont, "1234567890105")
        assert (cont.get_client().get_cnp() == "1234567890105")

        try:
            client_service.modificare_cnp_client(cont, "1234567890105")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "cnp-ul exista deja!\n")

        try:
            client_service.modificare_cnp_client(cont, "aaaa")
            assert (False)
        except Exception as ex:
            assert (str(ex) == "cnp invalid!\n")

    def __test_modify_client_name(self):
        client_repository = ConturiClientiRepository()
        client_validator = ClientValidator()
        client_service = ServiceClient(client_validator, client_repository)

        client_service.adauga_client(1, "Andrei", "1234567890125")
        client_service.adauga_client(2, "Mihai", "1234567890120")

        cont = client_service.get_client_by_id(2)
        client_service.modificare_nume_client(cont, "Mihnea")

        assert (cont.get_client().get_nume() == "Mihnea")


    def __test_rent_book(self):
        Book_repository = RepoBookCopies()
        Book_validator = BookValidator()
        Book_service = BookService(Book_validator, Book_repository)

        client_repository = ConturiClientiRepository()
        client_validator = ClientValidator()
        client_service = ServiceClient(client_validator, client_repository)

        Book_service.add_book(1, "Ion", "-", "Rebreanu", 5)
        Book_service.add_book(2, "Alice", "frumos", "Autor", 1)
        Book_service.add_book(3, "Book3", "--", "Autortrei", 0)

        Book1 = Book_service.get_book_by_id(1)
        Book2 = Book_service.get_book_by_id(2)
        Book3 = Book_service.get_book_by_id(3)

        client_service.adauga_client(1, "Andrei", "1234567890120")
        client1 = client_service.get_client_by_id(1)

        client_service.rent_book(client1, Book1)
        assert (Book1.get_Copies_number() == 4)
        assert (client1.get_carti_inchiriate() == [Book1.get_book()])

        client_service.rent_book(client1, Book2)
        assert (Book2.get_Copies_number() == 0)

        try:
            client_service.rent_book(client1, Book2)
            assert(False)
        except Exception as ex:
            assert (str(ex) == "clientul are deja cartea!\n")

        try:
            client_service.rent_book(client1, Book3)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "carte indisponibila!\n")
    
    def __test_search_client(self):
        client_repo = ConturiClientiRepository()
        client_validator = ClientValidator()
        client_service = ServiceClient(client_validator, client_repo)

        client_service.adauga_client(1,"david andrei","1234567890120")
        client_service.adauga_client(2,"stephen king","1234567890125")
        client_service.adauga_client(3,"david andrei","1234567890121")

        client = client_service.get_client_by_id(1)
        client1 = client_service.get_client_by_id(2)
        client2 = client_service.get_client_by_id(3)

        assert(client_repo.search_clients_by_id(3) == client2)
        assert(client_repo.search_clients_by_cnp("1234567890125") == client1)

        local_clients = []
        local_clients.append(client.get_client().get_id_client())
        local_clients.append(client2.get_client().get_id_client())
        
        assert(client_repo.search_clients_by_name("david andrei") == local_clients)

    def run_teste_service_client(self):
        self.__test_create_service_client()
        self.__test_add_client()
        self.__test_get_client_by_id()
        self.__test_rent_book()
        self.__test_modify_client_name()
        self.__test_modify_client_cnp()
        self.__test_search_client()

class TestBookService():

    def __test_create_service_book(self):
        repository_Book = RepoBookCopies()
        validator_Book = BookValidator()
        service_Book = BookService(validator_Book, repository_Book)
        assert (service_Book.get_book_validator() == validator_Book)
        assert (service_Book.get_book_repo() == repository_Book)

    def __test_add_book(self):
        repository_Book = RepoBookCopies()
        validator_Book = BookValidator()
        service_Book = BookService(validator_Book, repository_Book)
        assert (service_Book.get_book_repo().get_repository() == [])
        service_Book.add_book(1, "Ion", "-", "Rebreanu", 6)
        try:
            service_Book.add_book(1, "Ion", "-", "Rebreanu", 6)
        except Exception as ex:
            assert (str(ex) == "id deja existent!\ncarte deja existenta!\n")

    def __test_get_book_by_id(self):
        repository_Book = RepoBookCopies()
        validator_Book = BookValidator()
        service_Book = BookService(validator_Book, repository_Book)
        service_Book.add_book(1, "Ion", "-", "Liviu Rebreanu", 3)
        assert (service_Book.get_book_by_id(1) == Copies(Book(1, "Ion", "-", "Liviu Rebreanu"), 3))
        try:
            service_Book.get_book_by_id(-1)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id carte invalid!\n")
        try:
            service_Book.get_book_by_id(2)
            assert (False)
        except Exception as ex:
            assert (str(ex) == "id inexistent!\n")


    def run_teste_service_Book(self):
        self.__test_create_service_book()
        self.__test_add_book()
        self.__test_get_book_by_id()



class Test():

    def __init__(self):
        self.__test_client = TestClient()
        self.__test_book = BookTest()
        self.__test_client_repo = TestClientsRepoAccounts()
        self.__test_client_validator = TestClientValidator()
        self.__test_copies = TestCopies()
        self.__test_repo_copies = TestBooksRepoCopies()
        self.__test_book_validator = BookValidatorTest()
        self.__test_client_service = TestServiceClient()
        self.__test_book_service = TestBookService()

    def run_all_tests(self):
        '''
        Rulreaza toate testele aplicatiei
        :return:
        '''
        self.__test_client.run_teste_client()
        print(colorama.Fore.GREEN+"Teste client trecute!")
        self.__test_book.run_teste_Book()
        print(colorama.Fore.GREEN+"Teste carte trecute!")
        self.__test_client_repo.run_teste_repository_clienti()
        print(colorama.Fore.GREEN+"Teste repo clienti trecute!")
        self.__test_client_validator.run_teste_validare_client()
        print(colorama.Fore.GREEN+"Teste validare clienti trecute!")
        self.__test_copies.run_teste_Copies()
        print(colorama.Fore.GREEN+"Teste copii trecute!")
        self.__test_repo_copies.run_teste_repository_Copies()
        print(colorama.Fore.GREEN+"Teste repo copii trecute!")
        self.__test_book_validator.run_teste_validare_Book()
        print(colorama.Fore.GREEN+"Teste validare carte trecute!")
        self.__test_client_service.run_teste_service_client()
        print(colorama.Fore.GREEN+"Teste service client trecute!")
        self.__test_book_service.run_teste_service_Book()
        print(colorama.Fore.GREEN+"Teste service carte trecute!")
