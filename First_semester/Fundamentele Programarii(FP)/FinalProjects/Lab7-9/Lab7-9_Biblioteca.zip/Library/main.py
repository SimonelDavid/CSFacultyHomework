from UI.console import UserConsole

from Domain.client import ClientAccount
from Domain.book import Copies

from Repository.client_repo import ConturiClientiRepository
from Repository.book_repo import RepoBookCopies

from Service.client_service import ServiceClient
from Service.book_service import BookService

from Validation.client_validator import ClientValidator
from Validation.book_validator import BookValidator

from Testing.test import Test

test = Test()
test.run_all_tests()

client_repository = ConturiClientiRepository()
client_validator = ClientValidator()

book_repo = RepoBookCopies()
book_validator = BookValidator()

client_service = ServiceClient(client_validator, client_repository)
book_service = BookService(book_validator, book_repo)

user_console = UserConsole(client_service, book_service)
user_console.run()

#DE MODIFICAT
#7 FUNCTII IN REPO, SA MUT SEARCH SI MAX DIN REPO IN SERVICE