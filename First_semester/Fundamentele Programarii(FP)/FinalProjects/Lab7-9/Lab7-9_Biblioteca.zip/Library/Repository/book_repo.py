import colorama
from Domain.book import Copies, Book

import colorama
colorama.init()

class RepoBookCopies():
    '''
    Clasa RepoBookCopies() se ocupa cu crearea repository-ului pentru obiecte de tip Copies()
    '''
    #Constructor
    def __init__(self):

        self.__Copies_carti_repository = []

    def creare_exemplar(self, id_Book, titlu, descriere, autor, nr_Copies):
        return Copies(Book(id_Book, titlu, descriere, autor), nr_Copies)

    def get_repository(self):
        '''
        getter pentru __Copies_carti_repository
        :return: __Copies_carti_repository
        '''
        return self.__Copies_carti_repository

    def add_exemplar(self, Copies):
        '''
        Adauga un exemplar nou in repository
        :param Copies: obiect de tipul Copies()
        :return: -
        '''
        self.__Copies_carti_repository.append(Copies)

    def delete_exemplar(self, poz):
        '''
        Sterge exemplarul de pe pozitia poz
        :param poz: numar intreg nenul
        :return: -
        '''
        del(self.__Copies_carti_repository[poz])

    def get_book_by_id(self, id_Book):
        '''
        Returneaza Booka din repository care are id-ul id_Book. Daca nu exista retunreaza eroare
        :return:
        :raises Exception: "id inexistent!\n" daca id_Book nu este gasit
        '''
        for Book in self.__Copies_carti_repository:
            if Book.get_book().get_book_id() == id_Book: return Book
        raise Exception("id inexistent!\n")
    
    def delete_book(self, id):
        self.__mid = []

        for book in self.__Copies_carti_repository:
            if id != book.get_book().get_book_id():
                self.__mid.append(book)
        
        self.__Copies_carti_repository = []
        self.__Copies_carti_repository = self.__mid

    def max_book_title_repository(self):
        '''
            Functia max_book_title_repository(self) are rolul de a gasi si returna cartea cu titlul de lungime maxima
        '''
        
        max_book = self.__Copies_carti_repository[0]

        for i in range (1, len(self.__Copies_carti_repository)):
            if len(self.__Copies_carti_repository[i].get_book().get_titlu()) >= len(max_book.get_book().get_titlu()):
                max_book = self.__Copies_carti_repository[i]
        
        return max_book
    
    def search_book_by_id(self, id):

        if len(self.__Copies_carti_repository) == 0:
            raise Exception("Nu sunt carti introduse.")
        else:
            for i in range(0,len(self.__Copies_carti_repository)):
                if self.__Copies_carti_repository[i].get_book().get_book_id() == id:
                    return self.__Copies_carti_repository[i]
            raise Exception("ID-ul introdus nu este unul corespondent cu una din cartile din biblioteca.")
    
    def search_books_by_title(self, title):
        if len(self.__Copies_carti_repository) == 0:
            raise Exception("Nu sunt carti introduse.")
        else:
            local_books = []
            for i in range(0,len(self.__Copies_carti_repository)):
                if self.__Copies_carti_repository[i].get_book().get_titlu() == title:
                    local_books.append(self.__Copies_carti_repository[i].get_book().get_book_id())
            if len(local_books) == 0:
                raise Exception("Titlul introdus nu este unul corespondent uneia dintre cartile aflate in biblioteca.")
            else:
                return local_books
    
    def search_books_by_author(self, author):
        if len(self.__Copies_carti_repository) == 0:
            raise Exception("Nu sunt carti introduse.")
        else:
            local_books = []
            for i in range(0,len(self.__Copies_carti_repository)):
                if self.__Copies_carti_repository[i].get_book().get_autor() == author:
                    local_books.append(self.__Copies_carti_repository[i].get_book().get_book_id())
            if len(local_books) == 0:
                raise Exception("Autorul introdus nu este unul corespondent uneia dintre cartile aflate in biblioteca.")
            else:
                return local_books