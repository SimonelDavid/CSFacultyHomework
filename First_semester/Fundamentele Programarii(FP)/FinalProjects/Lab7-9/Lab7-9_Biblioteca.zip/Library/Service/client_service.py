import random
import string

class ServiceClient():

    #Conctructor
    def __init__(self, validator_client, repository_client):
        self.__validator_client = validator_client
        self.__repository_client = repository_client

    def adauga_client(self, id_client, nume, cnp):
        '''
        Functia adauga un client nou in repository
        :param id_client: numar natural nenul
        :param nume: string nevid
        :param cnp: string nevid, contine doar cifre
        :return: -
        :raises - "id client invalid!\n" daca id_client este invalid
                - "nume invalid!\n" daca nume este invalid
                - "cnp invalid!\n" daca cnp este invalid
                - "id deja existent!\n" daca id-ul apare deja in repository
                - "cnp deja existent!\n" daca cnp-ul apare deja in repository
        '''
        #validare ca datele sa fie corecte
        self.__validator_client.validare_date_client(id_client, nume, cnp)
        #validare unicitate
        self.__validator_client.validare_unicitate(self.__repository_client, cnp, id_client)
        self.__repository_client.add_cont(self.__repository_client.creare_cont_nou(id_client, nume, cnp))
    
    def delete_client(self, id):
        self.__repository_client.delete_account(id)

    def get_client_by_id(self, id_client):
        '''
        Functia returneaza contul clientului cu id-ul id_client din repository-ul clientilor
        :param id_client: numar natural nenul
        :return: ContClient() cu id-ul id_client
        :raises Exception: "id inexistent!\n", daca id_client nu exista in lista clientilor
        '''
        self.__validator_client.validare_id_client(id_client)
        return self.__repository_client.get_cont_by_id(id_client)
    
    def modify_client_id(self, cont, id_nou):
        '''
        Functia modifica id-ul contului cont cu id_nou
        :param cont:- obiect de tipul ContClient()
        :param id_nou: intreg nevid
        :return: -
        :raises Exception: "id client invalid!\n", daca numele introdus e vid
        '''
        self.__validator_client.validare_id_client(id_nou)
        cont.get_client().set_id_client(id_nou)

    def modificare_nume_client(self, cont, nume_nou):
        '''
        Functia modifica numele contului cont cu nume_nou
        :param cont:- obiect de tipul ContClient()
        :param nume_nou: string nevid
        :return: -
        :raises Exception: "nume invalid!\n", daca numele introdus e vid
        '''
        self.__validator_client.validare_nume_client(nume_nou)
        cont.get_client().set_nume(nume_nou)

    def modificare_cnp_client(self, cont, cnp_nou):
        '''
        Functia modifica cnp-ul contului cont cu cnp_nou
        :param cont: - obiect de tipul ContClient()
        :param cnp_nou: string nevid, contine doar cifre
        :return:  -
        :raises Exception: "cnp invalid!\n", daca cnp-ul este vid sau contine caractere diferite de cifre
                           "cnp-ul exista deja!\n", daca cnp_nou apare deja asupra altui cont
        '''
        self.__validator_client.validare_cnp_client(self.__repository_client, cnp_nou)
        cont.get_client().set_cnp(cnp_nou)

    def rent_book(self, cont_client, carte):
        '''
        Functia atribuie cartea carte catre cont_client
        :param cont_client: obiect de tipul ContClient()
        :param carte: obiect de tipul Exemplare()
        :return: -
        :raises Exception: - "carte indisponibila!\n" daca cartea carte are 0 exemplare disponibile
                           - "clientul are deja cartea!\n" daca cartea se regaseste in lista clientului de carti
        '''

        if carte.get_book() in cont_client.get_carti_inchiriate():
            raise Exception("clientul are deja cartea!\n")
        if carte.get_Copies_number() == 0:
            raise Exception("carte indisponibila!\n")
        cont_client.add_book(carte.get_book())
        carte.sub_copies(1)
        carte.add_rents()

    def search_client(self, crtieria, mode):
        if mode == 0:
            return self.__repository_client.search_clients_by_id(crtieria)
        elif mode == 1:
            return self.__repository_client.search_clients_by_cnp(crtieria)
        elif mode == 2:
            return self.__repository_client.search_clients_by_name(crtieria)

    def get_validator_client(self):
        return self.__validator_client

    def get_repository_client(self):
        return self.__repository_client
    
    def specific_string(self,length):  
        sample_string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqerstuvwxyz' # define the specific string  
        # define the condition for random string  
        result = ''.join((random.choice(sample_string)) for x in range(length))  
        return result  
  

    def clients_random(self, n):

        i = 0
        
        while i<n:
            #j = 0
            id = 0
            name = ""
            x = 0
            cnp = 0
            try:
                id = random.randint(1,100)
                self.__validator_client.validare_id_client(id)
                #j = j+1
            except Exception as ex:
                print(ex)
                #j = 0

            try:
                x = random.randint(10,35)
                name = self.specific_string(x)
                self.__validator_client.validare_nume_client(name)
                #j = j+1
            except Exception as ex:
                print(ex)
                #j = 0

            try:
                cnp1 = random.randint(1000000000000,9999999999999)
                cnp = str(cnp1)
                self.__validator_client.validare_cnp_client(self.__repository_client,cnp)
                #j = j+1
            except Exception as ex:
                print(ex)
                #j = 0
            
            #if j == 3:
            i = i+1
            self.adauga_client(id,name,cnp)