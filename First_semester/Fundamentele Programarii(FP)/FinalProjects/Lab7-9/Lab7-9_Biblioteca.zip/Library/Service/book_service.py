class BookService():

    #Constructor
    def __init__(self, book_validator, book_repo):
        self.__book_validator = book_validator
        self.__book_repo = book_repo

    def add_book(self, id_carte, titlu, descriere, autor, numar_exemplare):
        '''
        Functia adauga o carte noua in repository-ul cartilor
        :param id_carte: numar natural nenul
        :param titlu: string nevid
        :param descriere: string nevid
        :param autor: string nevid, contine doar litere
        :param numar_exemplare: numar natural
        :return:
        :raises Exception: "id carte invalid!\n" - daca id_carte este invalid
                           "titlu carte invalid!\n" - daca titlul cartii este invalid
                           "descriere carte invalida!\n" - daca descrierea cartii este invalida
                           "nume autor invalid!\n" - daca numele autorului este invalid
        '''
        self.__book_validator.book_data_validator(id_carte, titlu, descriere, autor)
        self.__book_validator.validare_unicitate(self.__book_repo, id_carte, titlu, autor)
        self.__book_repo.add_exemplar(self.__book_repo.creare_exemplar(id_carte, titlu, descriere, autor, numar_exemplare))
    
    def delete_book(self, id):

        self.__book_repo.delete_book(id)

    def max_book_title(self):
        '''
        Functia sorteaza repository-ul crescator dupa numarul de exemplare disponibile
        :return:
        '''
        return self.__book_repo.max_book_title_repository()
    
    def search_book(self, criteria, mode):
        if mode == 0:
            return self.__book_repo.search_book_by_id(criteria)
        elif mode == 1:
            return self.__book_repo.search_books_by_title(criteria)
        elif mode == 2:
            return self.__book_repo.search_books_by_author(criteria)

    def get_book_by_id(self, id_carte):
        '''
        Functia returneaza, daca gaseste, cartea cu id-ul id_carte din repository
        :param id_carte: numar natural nenul
        :return: obiect de tip Exemplare(), daca este gasit
        :raises Exception: "id carte invalid!\n" daca id-ul <= 0
                           "id inexistent!\n" daca id-ul nu este gasit
        '''
        self.__book_validator.validare_id_carte(id_carte)
        return self.__book_repo.get_book_by_id(id_carte)

    def modify_book_id(self, book, new_id):
        '''
        Functia modifica id-ul cartii book cu new_id
        :param cont:- obiect de tipul Book()
        :param id_nou: intreg nevid
        :return: -
        :raises Exception: "id carte invalid!\n", daca id-ul introdus e negativ
        '''
        self.__book_validator.validare_id_carte(new_id)
        book.get_book().set_book_id(new_id)

    def modify_book_title(self, book, new_title):
        '''
        Functia modifica titlului cartii book cu new_title
        :param cont:- obiect de tipul Book()
        :param id_nou: intreg nevid
        :return: -
        :raises Exception: "titlu carte invalid!\n", daca titlul introdus e vid
        '''
        self.__book_validator.book_title_validation(new_title)
        book.get_book().set_title(new_title)
    
    def modify_book_author(self, book, new_author):
        '''
        Functia modifica autorul cartii book cu new_author
        :param cont:- obiect de tipul Book()
        :param id_nou: intreg nevid
        :return: -
        :raises Exception: "autor carte invalid!\n", daca autorul introdus e vid
        '''
        self.__book_validator.book_author_validation(new_author)
        book.get_book().set_author(new_author)
    
    def modify_book_description(self, book, new_description):
        '''
        Functia modifica descrierea cartii book cu new_description
        :param cont:- obiect de tipul Book()
        :param id_nou: intreg nevid
        :return: -
        :raises Exception: "descriere carte invalida!\n", daca descrierea introdusa e vida
        '''
        self.__book_validator.book_description_validator(new_description)
        book.get_book().set_description(new_description)

    def get_book_validator(self):
        return self.__book_validator


    def get_book_repo(self):
        return self.__book_repo
